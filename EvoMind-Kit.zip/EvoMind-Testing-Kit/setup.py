#!/usr/bin/env python3
"""
EvoMind Testing Kit Setup
------------------------
Automatic setup script for EvoMind Testing Kit
Developed by Rujevo AI

© 2025 Rujevo - ALL RIGHTS RESERVED
"""

import os
import sys
import platform
import subprocess
import shutil
import time
from datetime import datetime
import pkg_resources
import colorama
from colorama import Fore, Style

# Initialize colorama for cross-platform color support
colorama.init()

class SetupManager:
    def __init__(self):
        self.os_type = platform.system().lower()
        self.python_cmd = self._get_python_command()
        self.pip_cmd = self._get_pip_command()
        self.log_file = f"setup_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        self.required_space = 500  # Required space in MB
        self.min_python_version = (3, 8)

    def _get_python_command(self):
        """Determine the correct Python command"""
        if shutil.which('python3'):
            return 'python3'
        elif shutil.which('python'):
            return 'python'
        else:
            self.log_error("Python not found! Please install Python 3.8 or higher.")
            sys.exit(1)

    def _get_pip_command(self):
        """Determine the correct pip command"""
        if shutil.which('pip3'):
            return 'pip3'
        elif shutil.which('pip'):
            return 'pip'
        else:
            self.log_error("pip not found! Please install pip.")
            sys.exit(1)

    def log_message(self, message, color=Fore.WHITE):
        """Log a message to both console and log file"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        console_message = f"{color}{message}{Style.RESET_ALL}"
        log_message = f"{timestamp}: {message}"
        
        print(console_message)
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(f"{log_message}\n")

    def log_error(self, message):
        """Log an error message"""
        self.log_message(f"ERROR: {message}", Fore.RED)

    def log_success(self, message):
        """Log a success message"""
        self.log_message(message, Fore.GREEN)

    def log_warning(self, message):
        """Log a warning message"""
        self.log_message(message, Fore.YELLOW)

    def check_system_requirements(self):
        """Check if system meets all requirements"""
        self.log_message("Checking system requirements...", Fore.CYAN)
        
        # Check Python version
        version = sys.version_info
        if version < self.min_python_version:
            self.log_error(f"Python {self.min_python_version[0]}.{self.min_python_version[1]} or higher is required!")
            sys.exit(1)
        self.log_success(f"Python version check passed: {sys.version}")

        # Check available disk space
        try:
            if self.os_type == 'windows':
                free_space = shutil.disk_usage('.').free // (1024 * 1024)  # Convert to MB
            else:
                free_space = os.statvfs('.').f_frsize * os.statvfs('.').f_bavail // (1024 * 1024)
            
            if free_space < self.required_space:
                self.log_error(f"Insufficient disk space. Required: {self.required_space}MB, Available: {free_space}MB")
                sys.exit(1)
            self.log_success(f"Disk space check passed: {free_space}MB available")
        except Exception as e:
            self.log_warning(f"Could not verify disk space: {str(e)}")

    def check_network_connectivity(self):
        """Check if we can connect to PyPI"""
        self.log_message("Checking network connectivity...", Fore.CYAN)
        try:
            import urllib.request
            urllib.request.urlopen('https://pypi.org', timeout=5)
            self.log_success("Network connectivity check passed")
            return True
        except Exception as e:
            self.log_error(f"Network connectivity check failed: {str(e)}")
            return False

    def create_virtual_env(self):
        """Create virtual environment with error handling and retry"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                if os.path.exists('venv'):
                    self.log_message("Virtual environment already exists.", Fore.YELLOW)
                    return

                self.log_message("Creating virtual environment...", Fore.CYAN)
                subprocess.check_call([self.python_cmd, '-m', 'venv', 'venv'])
                self.log_success("Virtual environment created successfully.")
                return
            except subprocess.CalledProcessError as e:
                if attempt < max_retries - 1:
                    self.log_warning(f"Attempt {attempt + 1} failed, retrying...")
                    time.sleep(2)
                else:
                    self.log_error(f"Failed to create virtual environment after {max_retries} attempts: {str(e)}")
                    sys.exit(1)

    def activate_virtual_env(self):
        """Prepare virtual environment activation"""
        if self.os_type == 'windows':
            activate_script = os.path.join('venv', 'Scripts', 'activate')
        else:
            activate_script = os.path.join('venv', 'bin', 'activate')
        
        if os.path.exists(activate_script):
            self.log_success("Virtual environment is ready for activation.")
            if self.os_type == 'windows':
                self.log_message("\nTo activate, run:\nvenv\\Scripts\\activate", Fore.CYAN)
            else:
                self.log_message("\nTo activate, run:\nsource venv/bin/activate", Fore.CYAN)
        else:
            self.log_error(f"Activation script not found: {activate_script}")

    def install_requirements(self):
        """Install required packages with progress tracking"""
        try:
            self.log_message("Installing required packages...", Fore.CYAN)
            
            # Upgrade pip first
            self.log_message("Upgrading pip...", Fore.CYAN)
            subprocess.check_call([self.pip_cmd, 'install', '--upgrade', 'pip'])
            
            # Install requirements
            if os.path.exists('requirements.txt'):
                # Read requirements file
                with open('requirements.txt', 'r') as f:
                    requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
                
                # Install each package with progress tracking
                total_packages = len(requirements)
                for i, package in enumerate(requirements, 1):
                    try:
                        self.log_message(f"Installing {package} ({i}/{total_packages})...", Fore.CYAN)
                        subprocess.check_call([self.pip_cmd, 'install', package])
                    except subprocess.CalledProcessError as e:
                        self.log_error(f"Failed to install {package}: {str(e)}")
                        if package in ['requests', 'colorama', 'python-dateutil']:  # Critical packages
                            raise
                
                self.log_success("Requirements installed successfully.")
            else:
                self.log_error("requirements.txt not found!")
                sys.exit(1)
        except subprocess.CalledProcessError as e:
            self.log_error(f"Failed to install requirements: {str(e)}")
            sys.exit(1)

    def verify_installation(self):
        """Verify that critical packages are installed correctly"""
        self.log_message("Verifying installation...", Fore.CYAN)
        critical_packages = ['requests', 'colorama', 'python-dateutil']
        
        try:
            for package in critical_packages:
                pkg_resources.require(package)
            self.log_success("Installation verification passed.")
            return True
        except pkg_resources.DistributionNotFound as e:
            self.log_error(f"Critical package not found: {str(e)}")
            return False
        except Exception as e:
            self.log_error(f"Verification error: {str(e)}")
            return False

    def setup(self):
        """Run the complete setup process"""
        banner = f"""
{Fore.CYAN}╔════════════════════════════════════════════╗
║        EvoMind Testing Kit Setup           ║
║        Developed by Rujevo AI              ║
╚════════════════════════════════════════════╝{Style.RESET_ALL}
"""
        print(banner)
        
        try:
            self.log_message(f"Starting setup on {self.os_type.capitalize()}")
            
            # Pre-installation checks
            self.check_system_requirements()
            if not self.check_network_connectivity():
                if not input("Continue anyway? (y/n): ").lower().startswith('y'):
                    sys.exit(1)
            
            # Main installation steps
            self.create_virtual_env()
            self.install_requirements()
            self.activate_virtual_env()
            
            # Post-installation verification
            if self.verify_installation():
                self.log_success("\n✅ Setup completed successfully!")
                self.log_message("\nTo start using the testing kit:", Fore.CYAN)
                if self.os_type == 'windows':
                    self.log_message("1. Run: venv\\Scripts\\activate", Fore.CYAN)
                else:
                    self.log_message("1. Run: source venv/bin/activate", Fore.CYAN)
                self.log_message("2. Run: python test.py", Fore.CYAN)
            else:
                self.log_error("\n⚠️ Setup completed with warnings. Please check the log file.")
            
        except Exception as e:
            self.log_error(f"Unexpected error during setup: {str(e)}")
            sys.exit(1)

def main():
    try:
        setup_manager = SetupManager()
        setup_manager.setup()
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Setup interrupted by user.{Style.RESET_ALL}")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Fore.RED}Fatal error: {str(e)}{Style.RESET_ALL}")
        sys.exit(1)

if __name__ == "__main__":
    main()
