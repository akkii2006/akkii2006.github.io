#!/usr/bin/env python3
"""

NOTE : This may not work properly!!!!!!! ######
EvoMind Testing Kit Setup
------------------------
Automatic setup script for EvoMind Testing Kit
Developed by Rujevo AI

© 2025 Rujevo - ALL RIGHTS RESERVED
"""

import os
import sys
import platform
import subprocess
import shutil
from datetime import datetime

class SetupManager:
    def __init__(self):
        self.os_type = platform.system().lower()
        self.python_cmd = self._get_python_command()
        self.pip_cmd = self._get_pip_command()
        self.log_file = f"setup_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

    def _get_python_command(self):
        """Determine the correct Python command"""
        if shutil.which('python3'):
            return 'python3'
        elif shutil.which('python'):
            return 'python'
        else:
            self.log_error("Python not found! Please install Python 3.8 or higher.")
            sys.exit(1)

    def _get_pip_command(self):
        """Determine the correct pip command"""
        if shutil.which('pip3'):
            return 'pip3'
        elif shutil.which('pip'):
            return 'pip'
        else:
            self.log_error("pip not found! Please install pip.")
            sys.exit(1)

    def log_message(self, message):
        """Log a message to both console and log file"""
        print(message)
        with open(self.log_file, 'a') as f:
            f.write(f"{datetime.now()}: {message}\n")

    def log_error(self, message):
        """Log an error message"""
        error_msg = f"ERROR: {message}"
        print(error_msg, file=sys.stderr)
        with open(self.log_file, 'a') as f:
            f.write(f"{datetime.now()}: {error_msg}\n")

    def check_python_version(self):
        """Check if Python version is compatible"""
        version = sys.version_info
        if version.major < 3 or (version.major == 3 and version.minor < 8):
            self.log_error("Python 3.8 or higher is required!")
            sys.exit(1)
        self.log_message(f"Python version check passed: {sys.version}")

    def create_virtual_env(self):
        """Create virtual environment"""
        try:
            if os.path.exists('venv'):
                self.log_message("Virtual environment already exists.")
                return

            self.log_message("Creating virtual environment...")
            subprocess.check_call([self.python_cmd, '-m', 'venv', 'venv'])
            self.log_message("Virtual environment created successfully.")
        except subprocess.CalledProcessError as e:
            self.log_error(f"Failed to create virtual environment: {str(e)}")
            sys.exit(1)

    def activate_virtual_env(self):
        """Activate virtual environment"""
        if self.os_type == 'windows':
            activate_script = os.path.join('venv', 'Scripts', 'activate')
        else:
            activate_script = os.path.join('venv', 'bin', 'activate')
        
        if os.path.exists(activate_script):
            self.log_message("Virtual environment is ready for activation.")
            if self.os_type == 'windows':
                self.log_message("\nTo activate, run:\nvenv\\Scripts\\activate")
            else:
                self.log_message("\nTo activate, run:\nsource venv/bin/activate")
        else:
            self.log_error(f"Activation script not found: {activate_script}")

    def install_requirements(self):
        """Install required packages"""
        try:
            self.log_message("Installing required packages...")
            
            # Upgrade pip first
            subprocess.check_call([self.pip_cmd, 'install', '--upgrade', 'pip'])
            
            # Install requirements
            if os.path.exists('requirements.txt'):
                subprocess.check_call([self.pip_cmd, 'install', '-r', 'requirements.txt'])
                self.log_message("Requirements installed successfully.")
            else:
                self.log_error("requirements.txt not found!")
                sys.exit(1)
        except subprocess.CalledProcessError as e:
            self.log_error(f"Failed to install requirements: {str(e)}")
            sys.exit(1)

    def setup(self):
        """Run the complete setup process"""
        banner = """
╔════════════════════════════════════════════╗
║        EvoMind Testing Kit Setup           ║
║        Developed by Rujevo AI              ║
╚════════════════════════════════════════════╝
"""
        print(banner)
        
        try:
            self.log_message(f"Starting setup on {self.os_type.capitalize()}")
            self.check_python_version()
            self.create_virtual_env()
            self.install_requirements()
            self.activate_virtual_env()
            
            self.log_message("\n✅ Setup completed successfully!")
            self.log_message("\nTo start using the testing kit:")
            if self.os_type == 'windows':
                self.log_message("1. Run: venv\\Scripts\\activate")
            else:
                self.log_message("1. Run: source venv/bin/activate")
            self.log_message("2. Run: python test.py")
            
        except Exception as e:
            self.log_error(f"Unexpected error during setup: {str(e)}")
            sys.exit(1)

def main():
    setup_manager = SetupManager()
    setup_manager.setup()

if __name__ == "__main__":
    main()
