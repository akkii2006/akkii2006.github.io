"""
EvoMind 1.2 Server-Based Testing Module
------------------------------------------------
Date: 29.01.2025
Developed by: Rujevo AI

© 2025 Rujevo - ALL RIGHTS RESERVED
"""

import os
import re
import sys
import csv
import getpass
import requests
from datetime import datetime
from typing import Dict, Any
import zipfile
from io import BytesIO


# ANSI Color Codes for Enhanced Formatting
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


AGREEMENT_TEXT = f'''
{Colors.HEADER}Rujevo - CONFIDENTIALITY AND TESTING AGREEMENT{Colors.ENDC}
------------------------------------------------

{Colors.BOLD}By proceeding with this testing kit, you agree to the following terms:{Colors.ENDC}

1. This testing kit is the exclusive property of Rujevo
2. You will not share, distribute, or leak this testing kit to any third party
3. All test results and feedback are confidential
4. This software is for authorized employees of Rujevo only
5. Any unauthorized use or distribution is strictly prohibited

{Colors.WARNING}This is a proprietary tool developed by Rujevo AI. Unauthorized access, 
sharing, or distribution of this testing kit or its results may result 
in legal action and/or termination of employment.{Colors.ENDC}

Version: EvoMind 1.2
'''

INSTRUCTIONS = f'''
{Colors.HEADER}TESTING KIT INSTRUCTIONS{Colors.ENDC}
------------------------

1. Enter your employee name when prompted
2. Test messages by typing them into the console
3. Review the AI's prediction
4. Confirm if the prediction is correct (y/n)
5. Incorrect predictions will be logged for review
6. Type 'quit' to exit and send logs via email

{Colors.OKBLUE}Important Notes:{Colors.ENDC}
- DO NOT FORGET TO TYPE QUIT BEFORE EXITING!!
- Be thorough in your testing
- Include edge cases and various scenarios
- All feedback is valuable for model improvement
- Take breaks if needed for accuracy
'''


class ServerModerator:
    def __init__(self, base_url='https://evomind-11-production.up.railway.app/'):
        """Initialize the server-based moderation client"""
        self.moderation_url = f"{base_url}/api/moderate"
        self.email_url = f"{base_url}/api/email/send"

        # Setup CSV files
        self.feedback_file = 'feedback.csv'
        self.commands_file = 'commands.csv'

        # Initialize logging files
        self._initialize_logging_files()

        # Define comprehensive regex patterns
        self.email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        self.phone_patterns = [
            r'\+\d{1,3}[-\s]?\(?\d{3}\)?[-\s]?\d{3}[-\s]?\d{4}',
            r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            r'\b\(\d{3}\)\s?\d{3}[-.]?\d{4}\b',
            r'\b(?:\+\d{1,3}[-\s]?)?\d{3,4}[-\s]?\d{3}[-\s]?\d{4}\b',
        ]
        self.communication_patterns = [
            r'\b(?:send|share|give|drop)\s+(?:contact|number|details)\b',
            r'\b(?:reach|connect|pm|dm)\s+(?:privately|outside)\b',
            r'\b(?:message|text)\s+(?:me|privately)\b',
        ]

    def _initialize_logging_files(self):
        """Initialize logging CSV files with headers"""
        # Feedback file
        if not os.path.exists(self.feedback_file):
            with open(self.feedback_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'Timestamp', 'Employee', 'Message',
                    'Server Prediction', 'Correct Label'
                ])

        # Commands file
        if not os.path.exists(self.commands_file):
            with open(self.commands_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'Timestamp', 'Employee', 'Message', 'Server Prediction', 'Detected Patterns'
                ])

    def log_message(self, employee_name: str, message: str, result: Dict):
        """Log all commands with their predictions"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        patterns = str(result.get('detected_patterns', {}))

        with open(self.commands_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                timestamp,
                employee_name,
                message,
                result.get('server_prediction', 'Unknown'),
                patterns
            ])

    def log_incorrect_prediction(self, employee_name: str, message: str, prediction: Dict):
        """Log incorrect predictions to feedback CSV"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(self.feedback_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                timestamp,
                employee_name,
                message,
                prediction.get('server_prediction', 'Unknown'),
                'Safe' if prediction['is_unsafe'] else 'Unsafe'
            ])

    def send_logs(self, employee_name: str):
        """Zip and send log files to the server"""

        zip_filename = f"Logs_EvoMind-1.2_{employee_name}.zip"

        try:
            # Create zip file in memory
            zip_buffer = BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                # Add commands.csv if it exists
                if os.path.exists(self.commands_file):
                    zip_file.write(self.commands_file)

                # Add feedback.csv if it exists
                if os.path.exists(self.feedback_file):
                    zip_file.write(self.feedback_file)

            # Reset buffer position
            zip_buffer.seek(0)

            # Send the zip file
            files = {'file': (zip_filename, zip_buffer.getvalue())}
            response = requests.post(self.email_url, files=files, timeout=10)
            response.raise_for_status()

            print(f"{Colors.OKGREEN}Logs have been zipped and sent successfully!{Colors.ENDC}")
            return True

        except Exception as e:
            print(f"{Colors.FAIL}Error sending logs: {str(e)}{Colors.ENDC}")
            return False

    def _detect_local_patterns(self, message: str) -> Dict[str, list]:
        """Detect potentially unsafe patterns locally"""
        detected_patterns = {}

        # Email detection
        email_matches = re.findall(self.email_pattern, message, re.IGNORECASE)
        if email_matches:
            detected_patterns['emails'] = email_matches

        # Phone number detection
        phone_matches = []
        for phone_regex in self.phone_patterns:
            matches = re.findall(phone_regex, message)
            if matches:
                phone_matches.extend(matches)
        if phone_matches:
            detected_patterns['phone_numbers'] = phone_matches

        # Communication request detection
        comm_matches = []
        for comm_regex in self.communication_patterns:
            matches = re.findall(comm_regex, message, re.IGNORECASE)
            if matches:
                comm_matches.extend(matches)
        if comm_matches:
            detected_patterns['communication_requests'] = comm_matches

        return detected_patterns

    def check_message(self, message: str) -> Dict[str, Any]:
        """Check message safety with local and server-side detection"""
        try:
            # Local pattern detection
            local_patterns = self._detect_local_patterns(message)
            is_unsafe_locally = bool(local_patterns)

            # Server-side moderation
            response = requests.post(
                self.moderation_url,
                json={'message': message},
                timeout=10
            )
            response.raise_for_status()
            result = response.json()

            # Combine local and server detection
            final_is_unsafe = is_unsafe_locally or result.get('is_unsafe', False)

            return {
                'is_unsafe': final_is_unsafe,
                'detected_patterns': local_patterns,
                'server_prediction': 'Unsafe' if final_is_unsafe else 'Safe'
            }

        except requests.RequestException as e:
            print(f"{Colors.FAIL}Server communication error: {e}{Colors.ENDC}")
            return {
                'is_unsafe': False,
                'detected_patterns': {},
                'server_prediction': 'Error'
            }


def get_employee_agreement() -> bool:
    """Display agreement and get employee acceptance"""
    print(AGREEMENT_TEXT)
    while True:
        response = input(f"{Colors.OKBLUE}Do you agree to these terms? (yes/no): {Colors.ENDC}").lower().strip()
        if response == 'yes':
            return True
        elif response == 'no':
            return False
        else:
            print(f"{Colors.WARNING}Please answer 'yes' or 'no'{Colors.ENDC}")


def get_employee_name() -> str:
    """Get and validate employee name"""
    while True:
        name = input(f"{Colors.OKBLUE}Please enter your full name: {Colors.ENDC}").strip()
        if len(name) >= 2 and all(part.isalpha() or part.isspace() for part in name):
            confirm = input(f"{Colors.WARNING}Confirm your name is '{name}'? (y/n): {Colors.ENDC}").lower().strip()
            if confirm == 'y':
                return name
        print(f"{Colors.FAIL}Please enter a valid full name{Colors.ENDC}")


def interactive_testing():
    """Interactive testing session"""
    print(f"\n{Colors.HEADER}🔍 EvoMind 1.2 Server-Based Testing{Colors.ENDC}")

    # Get agreement
    if not get_employee_agreement():
        print(f"\n{Colors.FAIL}Agreement not accepted. Exiting...{Colors.ENDC}")
        sys.exit(1)

    # Get employee name
    employee_name = get_employee_name()

    # Show instructions
    print(INSTRUCTIONS)
    print(f"\n{Colors.OKGREEN}Welcome, {employee_name}{Colors.ENDC}")
    print("Enter messages to test. Type 'quit' to exit and send logs.")

    moderator = ServerModerator()

    while True:
        print("\nPlease DO NOT FORGET to type 'quit' before exiting")
        message = input(f"\n{Colors.BOLD}Enter message to test: {Colors.ENDC}").strip()

        if not message:
            print(f"{Colors.WARNING}Please enter a message!{Colors.ENDC}")
            continue

        if message.lower() == 'quit':
            print(f"\n{Colors.OKGREEN}Sending logs...{Colors.ENDC}")
            moderator.send_logs(employee_name)
            print(f"\n{Colors.OKGREEN}Testing session complete. Goodbye!{Colors.ENDC}")
            break

        try:
            result = moderator.check_message(message)

            # Log the message with prediction
            moderator.log_message(employee_name, message, result)

            status = f"{Colors.FAIL}❌ UNSAFE{Colors.ENDC}" if result[
                'is_unsafe'] else f"{Colors.OKGREEN}✅ SAFE{Colors.ENDC}"

            print(f"\n{Colors.HEADER}RESULTS:{Colors.ENDC}")
            print(f"Status: {status}")
            print(f"Server Prediction: {result['server_prediction']}")

            # Print detected patterns
            if result.get('detected_patterns'):
                print(f"\n{Colors.WARNING}UNSAFE PATTERNS DETECTED:{Colors.ENDC}")
                for pattern_type, matches in result['detected_patterns'].items():
                    print(f"{pattern_type.upper()}: {matches}")

            confirmation = input(f"\n{Colors.BOLD}Is this prediction correct? (y/n): {Colors.ENDC}").lower().strip()

            if confirmation == 'n':
                moderator.log_incorrect_prediction(employee_name, message, result)
                print(f"{Colors.OKGREEN}Feedback logged for review!{Colors.ENDC}")

        except Exception as e:
            print(f"{Colors.FAIL}Error processing message: {str(e)}{Colors.ENDC}")


def main():
    try:
        print(f"\n{'=' * 50}")
        print(f"{Colors.HEADER}EvoMind 1.2 Testing Kit{Colors.ENDC}")
        print(f"Developed by Rujevo AI")
        print(f"{'=' * 50}\n")

        interactive_testing()
    except KeyboardInterrupt:
        print(f"\n{Colors.WARNING}Session interrupted. Exiting...{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}An error occurred: {str(e)}{Colors.ENDC}")


if __name__ == "__main__":
    main()