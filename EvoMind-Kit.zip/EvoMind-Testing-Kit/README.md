# EvoMind 1.x Testing Kit
## Content Moderation System Test Suite

![Version](https://img.shields.io/badge/Version-1.1-blue)
![Status](https://img.shields.io/badge/Status-Production-green)

---

## ⚠️ CONFIDENTIALITY NOTICE

**PROPRIETARY SOFTWARE - Rujevo AI**

This software, including all associated files, documentation, and test results, is the exclusive intellectual property of Rujevo AI. This testing kit is provided under strict confidentiality and is intended for authorized personnel only.

### Legal Status
- **Copyright © 2025 Rujevo**
- **ALL RIGHTS RESERVED**
- Unauthorized copying, modification, or distribution is strictly prohibited
- Unauthorized access or sharing may result in legal action
- Commercial use requires explicit written permission

---

## 📋 Overview

EvoMind Testing Kit is a specialized tool designed for evaluating and improving our AI content moderation system. This kit enables authorized testers to validate message safety predictions and provide valuable feedback for model enhancement.

### Key Features
- Real-time message safety evaluation
- Automated feedback collection
- Employee tracking and accountability
- Comprehensive logging system
- Cross-platform compatibility

---

## 🛠️ System Requirements

### Minimum Requirements
- Python 3.8 or higher
- 4GB RAM
- 500MB free disk space

### Supported Operating Systems
- Windows 10/11
- macOS 12.0+
- Ubuntu 20.04+ or equivalent Linux distributions

---

## 📥 Installation

### Step 1: Environment Setup
```bash
# Create and activate virtual environment
python -m venv venv

# For Windows
venv\Scripts\activate

# For macOS/Linux
source venv/bin/activate
```

### Step 2: Install Dependencies
```bash
# Install required packages
pip install -r requirements.txt
```

---

## 🚀 Usage Guide

### Starting the Testing Kit
```bash
python test.py
```

### Testing Process
1. **Agreement Acceptance**
   - Review and accept the confidentiality agreement
   - Provide your full name for accountability

2. **Message Testing**
   - Enter messages for evaluation
   - Review AI predictions
   - Confirm prediction accuracy
   - Provide feedback for incorrect predictions

3. **Viewing Results**
   - Check feedback.csv for logged incorrect predictions
   - Review test history and performance metrics

### Example Session
```bash
$ python test.py

EvoMind 1.1 Testing Kit
-----------------------
> Please enter your full name: John Smith
> Enter message to test: Hello world
Status: ✅ SAFE
Confidence: 95.2%
Is this prediction correct? (y/n): y
```

---

## 📊 Feedback System

### Feedback Collection
- Incorrect predictions are automatically logged
- Includes timestamp and tester identification
- Structured data collection for model improvement

### CSV Format
```
Timestamp, Employee, Message, Server Prediction, Confidence, Correct Label
```

### ⚠️ Important: Data Submission
The feedback.csv file is generated locally and needs to be manually submitted. Please:
1. Complete your testing session
2. Locate the feedback.csv file in your testing directory
3. Send the file to: akkiisfrommars@icloud.com
4. Include your name and testing date in the email

---

## ⚠️ Important Guidelines

### Testing Best Practices
1. Test a diverse range of messages
2. Include edge cases
3. Verify both safe and unsafe content
4. Provide accurate feedback
5. Take regular breaks to maintain accuracy

### Security Measures
- Do not share access credentials
- Keep test results confidential
- Report security concerns immediately
- Log out after testing sessions
- Maintain a secure testing environment

---

## 🔒 Data Privacy

### Data Handling
- All test data is processed securely
- No persistent storage of message content
- Employee data is protected
- Compliance with data protection standards

---

## 📞 Support

### Contact Information
- Technical Support: support@rujevo.com
- General Inquiries: info@rujevo.com

---

## 🔄 Version History

### Current Version: 1.2
- Released: January 2025
- See changelog on website

### Upcoming Version: 1.3
- Expected: Soon
- More info on website

---

## ⚖️ Legal Information

### Terms of Use
1. Access limited to authorized personnel
2. No reverse engineering permitted
3. No unauthorized modifications
4. Confidentiality requirements apply
---

**© 2025 Rujevo - All Rights Reserved**

*Built with excellence by Rujevo AI*

[Internal Document - Confidential]