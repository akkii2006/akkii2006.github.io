"""
EvoMind 1.1 Server-Based Testing Module
------------------------------------------------
Date: 21.01.2025
Developed by: Rujevo AI

© 2025 Rujevo - ALL RIGHTS RESERVED
"""

import requests
import os
import csv
from datetime import datetime
import getpass
import sys

AGREEMENT_TEXT = '''
Rujevo - CONFIDENTIALITY AND TESTING AGREEMENT
------------------------------------------------

By proceeding with this testing kit, you agree to the following terms:

1. This testing kit is the exclusive property of Rujevo
2. You will not share, distribute, or leak this testing kit to any third party
3. All test results and feedback are confidential
4. This software is for authorized employees of Rujevo only
5. Any unauthorized use or distribution is strictly prohibited

This is a proprietary tool developed by Rujevo AI. Unauthorized access, 
sharing, or distribution of this testing kit or its results may result 
in legal action and/or termination of employment.

Version: EvoMind 1.X
'''

INSTRUCTIONS = '''
TESTING KIT INSTRUCTIONS
------------------------

1. Enter your employee name when prompted
2. Test messages by typing them into the console
3. Review the AI's prediction
4. Confirm if the prediction is correct (y/n)
5. Incorrect predictions will be logged for review
6. Type 'quit' to exit the testing session

Important Notes:
- Be thorough in your testing
- Include edge cases and various scenarios
- All feedback is valuable for model improvement
- Take breaks if needed for accuracy
'''


class ServerModerator:
    def __init__(self, server_url='https://evomind-11-production.up.railway.app/api/moderate'):
        """Initialize the server-based moderation client"""
        self.server_url = server_url

        # Setup logging directory
        os.makedirs('logs', exist_ok=True)

        # Prepare feedback CSV
        self.feedback_file = 'feedback.csv'
        self._initialize_feedback_file()

    def _initialize_feedback_file(self):
        """Initialize feedback CSV file with headers if it doesn't exist"""
        if not os.path.exists(self.feedback_file):
            with open(self.feedback_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'Timestamp',
                    'Employee',
                    'Message',
                    'Server Prediction',
                    'Confidence',
                    'Correct Label'
                ])

    def check_message(self, message):
        """Check message safety using server-side moderation"""
        try:
            # Send request to moderation server
            response = requests.post(
                self.server_url,
                json={'message': message},
                timeout=10  # 10-second timeout
            )

            # Check for successful response
            response.raise_for_status()

            # Parse server response
            result = response.json()

            return {
                'is_unsafe': result.get('is_unsafe', False),
                'safe_score': result.get('safe_score', 1),
                'unsafe_score': result.get('unsafe_score', 0)
            }

        except requests.RequestException as e:
            print(f"Server communication error: {e}")
            return {
                'is_unsafe': False,
                'safe_score': 1,
                'unsafe_score': 0
            }

    def log_incorrect_prediction(self, message, prediction, employee_name):
        """Log incorrect predictions to CSV with employee name"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(self.feedback_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                timestamp,
                employee_name,
                message,
                'Unsafe' if prediction['is_unsafe'] else 'Safe',
                f"{max(prediction['safe_score'], prediction['unsafe_score']):.2%}",
                'Safe' if prediction['is_unsafe'] else 'Unsafe'  # Opposite of prediction
            ])


def get_employee_agreement():
    """Display agreement and get employee acceptance"""
    print(AGREEMENT_TEXT)
    while True:
        response = input("\nDo you agree to these terms? (yes/no): ").lower().strip()
        if response == 'yes':
            return True
        elif response == 'no':
            return False
        else:
            print("Please answer 'yes' or 'no'")


def get_employee_name():
    """Get and validate employee name"""
    while True:
        name = input("\nPlease enter your full name: ").strip()
        if len(name) >= 2 and all(part.isalpha() or part.isspace() for part in name):
            confirm = input(f"Confirm your name is '{name}' (y/n): ").lower().strip()
            if confirm == 'y':
                return name
        print("Please enter a valid full name")


def interactive_testing():
    """Interactive testing session"""
    print("\n🔍 EvoMind 1.1 Server-Based Testing")

    # Get agreement
    if not get_employee_agreement():
        print("\nAgreement not accepted. Exiting...")
        sys.exit(1)

    # Get employee name
    employee_name = get_employee_name()

    # Show instructions
    print(INSTRUCTIONS)
    print("\nWelcome,", employee_name)
    print("Enter messages to test. Type 'quit' to exit.")

    moderator = ServerModerator()

    while True:
        message = input("\nEnter message to test: ").strip()

        if not message:
            print("Please enter a message!")
            continue

        if message.lower() == 'quit':
            print("\nExiting...")
            break

        try:
            result = moderator.check_message(message)

            status = "❌ UNSAFE" if result['is_unsafe'] else "✅ SAFE"
            confidence = max(result['safe_score'], result['unsafe_score'])

            print(f"\nStatus: {status}")
            print(f"Confidence: {confidence:.2%}")
            print(f"Safe Score: {result['safe_score']:.2%}")
            print(f"Unsafe Score: {result['unsafe_score']:.2%}")

            confirmation = input("\nIs this prediction correct? (y/n): ").lower().strip()

            if confirmation == 'n':
                moderator.log_incorrect_prediction(message, result, employee_name)
                print("Prediction logged for review!")

        except Exception as e:
            print(f"Error processing message: {str(e)}")


def main():
    try:
        print("\n" + "=" * 50)
        print("EvoMind 1.X Testing Kit")
        print("Developed by Rujevo AI")
        print("=" * 50 + "\n")

        interactive_testing()
    except KeyboardInterrupt:
        print("\nExiting...")
    except Exception as e:
        print(f"An error occurred: {str(e)}")


if __name__ == "__main__":
    main()